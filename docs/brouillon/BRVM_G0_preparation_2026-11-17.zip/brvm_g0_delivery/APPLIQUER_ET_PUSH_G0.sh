#!/usr/bin/env bash
# Apply the audited G0 patch to a fresh clone, test it, and push a NEW branch.
# Explicitly authorized operation: publishes a branch, never pushes to main.
set -euo pipefail
ARTIFACT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PATCH="$ARTIFACT_DIR/g0_changes.patch"
REPO_URL="${BRVM_REPO_URL:-https://github.com/BeediGoua/Agentic-Financial-RAG-Analyst.git}"
EXPECTED_BASE="${BRVM_EXPECTED_BASE:-a869755cc88c132f69a93aae7593d8e20413937e}"
BRANCH="chore/g0-reproducible-env-20261117"
TARGET="${1:-./Agentic-Financial-RAG-Analyst-G0}"
MODE="${2:-publish}"

if [[ ! -f "$PATCH" ]]; then
  echo "Patch not found: $PATCH" >&2
  exit 2
fi
if [[ -e "$TARGET" ]]; then
  echo "Target already exists: $TARGET (will not overwrite)." >&2
  exit 2
fi
if [[ "$MODE" != "publish" && "$MODE" != "--dry-run" ]]; then
  echo 'Usage: bash APPLIQUER_ET_PUSH_G0.sh [target_directory] [--dry-run]' >&2
  exit 2
fi

git clone "$REPO_URL" "$TARGET"
cd "$TARGET"
HEAD_SHA="$(git rev-parse HEAD)"
if [[ "$HEAD_SHA" != "$EXPECTED_BASE" ]]; then
  echo "Repository HEAD changed: $HEAD_SHA (expected $EXPECTED_BASE)." >&2
  echo "Stop: rebase/review the patch against the updated branch first." >&2
  exit 3
fi
if [[ -n "$(git status --porcelain)" ]]; then
  echo 'Working tree not clean after cloning; stopping.' >&2
  exit 4
fi
git switch -c "$BRANCH"
git apply --check "$PATCH"
git apply "$PATCH"

echo 'Patch applied successfully.'
if [[ "$MODE" == '--dry-run' ]]; then
  echo 'DRY RUN: no lock, packages, commit or remote push attempted.'
  git status --short
  exit 0
fi
if ! command -v uv >/dev/null 2>&1; then
  echo 'uv is required to resolve and hash-lock ALL dependencies before publishing.' >&2
  echo 'Install uv: https://docs.astral.sh/uv/' >&2
  exit 5
fi
if ! command -v python3.11 >/dev/null 2>&1; then
  echo 'Python 3.11 is required for the audited reference build.' >&2
  exit 5
fi

make lock
PYTHON_BIN=python3.11 bash scripts/bootstrap.sh
.venv/bin/python scripts/check_env.py --profile full || true

{
  echo ''
  echo '## Vérification machine connectée'
  echo ''
  echo "- Exécutée après application sur la révision de base \`$EXPECTED_BASE\`."
  echo '- `make lock` : résolution complète avec hashes réussie.'
  echo '- `bash scripts/bootstrap.sh` : installation isolée, tests et `pip check` réussis.'
  echo '- Le diagnostic `full` signale les éventuels composants externes absents ; ils ne sont pas téléchargés automatiquement.'
} >> docs/JOURNAL_G0.md

git add -- .env.example .python-version .github/workflows/g0-ci.yml Makefile \
  docs/JOURNAL_G0.md docs/SETUP_G0.md requirements.txt requirements-dev.txt \
  requirements.lock scripts/bootstrap.sh scripts/check_env.py scripts/lock.sh \
  scripts/prefetch_models.py scripts/test.sh tests/test_g0_config.py \
  tests/test_extraction_smoke.py

git commit -m 'chore(g0): reproducible Python setup, smoke tests and change journal'
git push --set-upstream origin "$BRANCH"
printf '\nBranch pushed: %s\n' "$BRANCH"
printf 'Open a PR: https://github.com/BeediGoua/Agentic-Financial-RAG-Analyst/compare/main...%s?expand=1\n' "$BRANCH"
