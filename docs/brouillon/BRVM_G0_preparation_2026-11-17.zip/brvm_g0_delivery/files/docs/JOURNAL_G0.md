# Journal technique — G0 : environnement et reproductibilité

Date : **17 novembre 2026**
Dépôt : `BeediGoua/Agentic-Financial-RAG-Analyst`
Base auditée : `main` / commit `a869755cc88c132f69a93aae7593d8e20413937e`

## Objectif

Obtenir une procédure d'installation isolée et vérifiable, avec une commande
unique de tests et un diagnostic explicite des prérequis non-Python.

## Changements proposés et raisons

| Fichier | Modification | Pourquoi |
| --- | --- | --- |
| `requirements.txt` | Version exacte pour chaque package direct, suppression des doublons et de `chromadb` inutilisé | Éviter les résolutions dérivantes ; ne pas installer de backend non implémenté |
| `requirements-dev.txt` | Versions exactes des outils de test | Stabiliser l'exécution des tests |
| `.python-version` | Python 3.11 | Version de référence largement prise en charge par les modèles ML et FAISS |
| `.env.example` | `qwen2.5:7b` et retrait de la fausse clé d'API | Aligner l'exemple sur le code de génération et éviter la confusion sur les secrets |
| `scripts/bootstrap.sh` | `.venv` isolé, install, `pip check`, tests, erreurs non masquées | Commande reproductible et conditions d'échec visibles |
| `scripts/test.sh` | Test de configuration + compileall + pytest + pip check | Une commande unique, sans connexion aux sources BRVM |
| `scripts/check_env.py` | Diagnostic core/full et option stricte | Repérer dépendances, binaire OCR, langues, Ollama et poids manquants |
| `scripts/prefetch_models.py` | Téléchargement explicite des modèles | Éviter les téléchargements imprévus pendant les tests |
| `scripts/lock.sh` | Résolution avec hashes via `uv` | Préparer le lock transitif reproductible quand PyPI sera accessible |
| `tests/test_g0_config.py` | Contrats des versions, registres et Ollama | Détecter un désalignement des configurations |
| `tests/test_extraction_smoke.py` | PDF synthétique et métadonnées | Détecter une casse de l'extracteur sans données privées |
| `.github/workflows/g0-ci.yml` | Bootstrap et tests en CI + inventaire | Répéter le setup sur une machine propre |
| `docs/SETUP_G0.md` | Procédures OS, installation, diagnostic et limites | Éviter la dépendance à une mémoire orale de l'environnement |

## Vérifications effectuées dans le conteneur d'audit

- `git ls-remote` vers `github.com` : **échec DNS**. Clone réseau intégral impossible.
- `pip install` des exigences précédentes : **échec de résolution réseau**.
- Python disponible : **3.13.5** uniquement ; cible de référence **3.11** non présente.
- `tesseract` : présent (version 5.5.0) ; `ollama` : absent.
- Paquets Python essentiels à l'indexation et aux LLM : `faiss-cpu`,
  `sentence-transformers` et `rank-bm25` absents ; installation intégrale
  impossible dans cet environnement isolé.
- Les 6 tests ciblés G0 ont réussi sur un **assemblage local partiel**
  des modules présents dans le dépôt (Python 3.13.5).
- Le diagnostic `core` a passé 19/22 contrôles (trois paquets absents).
  Le diagnostic `full` a passé 22/30 contrôles (Ollama et modèles absents).
- Le bootstrap réel `.venv` a correctement créé un environnement isolé,
  mais `pip install` a échoué (DNS PyPI inaccessible, code de sortie 1).
- Les 15 changements ont été convertis en patch Git et `git apply --check`
  a réussi contre les deux fichiers préexistants identifiés par leurs SHA.
- Publication : la création d'une branche et d'un blob Git via le
  connecteur GitHub ont retourné **HTTP 403 Resource not accessible by
  integration**. Aucune branche, PR ni modification distante créée.

## Conditions de sortie de G0 (à valider sur machine connectée)

- [ ] Clonage Git natif confirmé sur la branche G0 (ici : DNS impossible).
- [ ] `bash scripts/bootstrap.sh` réussi dans une venv **sans** system-site-packages.
- [ ] Lock transitif avec hashes `requirements.lock` commité.
- [ ] Installation sans conflit : `pip check`.
- [ ] `bash scripts/test.sh` réussi avec les vraies dépendances.
- [ ] CI verte sur une machine vierge Python 3.11 (workflow proposé non exécuté).
- [ ] Diagnostic `--profile full` réussi si les modèles et Ollama sont requis.

**Conclusion :** G0 est préparé mais ne peut pas être déclaré terminé avant
ces vérifications. Les failles fonctionnelles identifiées au précédent audit
relèvent de G1/G2/G3/G4 et ne sont pas masquées par le setup.
