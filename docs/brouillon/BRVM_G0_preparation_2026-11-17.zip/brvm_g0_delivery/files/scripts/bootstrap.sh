#!/usr/bin/env bash
# Deterministic entrypoint for a CLEAN Python virtual environment.
# Cannot work fully offline unless package wheels were cached beforehand.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PYTHON_BIN="${PYTHON_BIN:-python3.11}"
if ! command -v "$PYTHON_BIN" >/dev/null 2>&1; then
  echo "ERROR: $PYTHON_BIN is missing. Install Python 3.11 or set PYTHON_BIN=python3.12." >&2
  exit 2
fi
"$PYTHON_BIN" - <<'PY'
import sys
if not ((3,11) <= sys.version_info[:2] < (3,14)):
    raise SystemExit('Python 3.11, 3.12 or 3.13 required.')
PY
if [[ ! -x .venv/bin/python ]]; then
  "$PYTHON_BIN" -m venv .venv
fi
PY="${ROOT}/.venv/bin/python"
"$PY" -m pip install --upgrade 'pip==25.1.1'
if [[ -f requirements.lock ]]; then
  echo "Using fully resolved requirements.lock"
  "$PY" -m pip install --requirement requirements.lock
else
  echo "WARNING: requirements.lock is absent. Direct pins only; transitive versions are NOT locked." >&2
  "$PY" -m pip install --requirement requirements.txt --requirement requirements-dev.txt
fi
"$PY" -m pip check
"$PY" scripts/check_env.py --profile core --strict
if [[ "${1:-}" != "--no-tests" ]]; then
  bash scripts/test.sh
fi
cat <<'MSG'
Environment installed. To check OCR, Ollama and model cache, run:
  .venv/bin/python scripts/check_env.py --profile full
To prepare/download models (network needed), run:
  .venv/bin/python scripts/prefetch_models.py --all
  ollama pull qwen2.5:7b
MSG
