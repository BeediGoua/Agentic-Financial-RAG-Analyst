# Tests G0 du 17 novembre 2026

- `bash -n scripts/bootstrap.sh scripts/test.sh scripts/lock.sh` : **PASS**.
- `python -m compileall -q scripts tests` : **PASS**.
- `python -m pytest tests -q` : **6 PASS**, sur assemblage partiel des
  modules GitHub déjà vérifiés dans l'audit, Python 3.13.5.
- `python scripts/check_env.py --profile core --json` : **19/22**
  contrôles passés ; manquent `faiss-cpu`, `sentence-transformers`, `rank-bm25`.
- `python scripts/check_env.py --profile full --json` : **22/30** ;
  manquent en plus Ollama et les poids HF. OCR `fra`/`eng` est présent.
- `PYTHON_BIN=python3.13 bash scripts/bootstrap.sh --no-tests` dans une
  venv isolée : **FAILED (exit 1)** car l'index PyPI est inaccessible. La
  venv a bien été créée sans accès aux bibliothèques globales.
- `git apply --check` sur originaux GitHub identifiés par SHA : **PASS**.
- `git apply`, suivi d'une comparaison octet à octet : **15/15 fichiers
  identiques à la préparation G0**.
- `git ls-remote` / `git clone` réseau : **FAILED (GitHub DNS)**.
- Écriture GitHub : `create_branch` et `create_blob` : **403 Resource not
  accessible by integration**. Aucun push effectué.

**Ne pas confondre ces tests partiels et une qualification G0 complète.** La
CI et la venv Python 3.11 attendent un réseau et des permissions d'écriture.
