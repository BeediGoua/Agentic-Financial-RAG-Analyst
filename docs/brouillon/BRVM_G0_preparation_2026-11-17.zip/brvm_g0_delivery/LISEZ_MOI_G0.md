# BRVM G0 : livraison du 17 novembre 2026

Ce paquet contient un patch Git de 15 fichiers, la version lisible des fichiers,
le journal des changements et un script optionnel pour **cloner, résoudre le
lock, tester et pousser une branche**. Il ne contient ni données BRVM ni secrets.

**État actuel** : tests locaux ciblés validés, mais le clone et l'installation
complète ne sont pas possibles sur le serveur d'audit (DNS GitHub/PyPI refusé).
La connexion GitHub en lecture fonctionne, mais le connecteur refuse les
écritures avec `HTTP 403 Resource not accessible by integration`. Donc
**aucun push/commit/PR n'a eu lieu sur le vrai dépôt**.

## Solution automatisée sur une machine connectée à GitHub/PyPI

```bash
unzip BRVM_G0_preparation_2026-11-17.zip
cd brvm_g0_delivery
bash APPLIQUER_ET_PUSH_G0.sh
```

Elle :
1. Clone le dépôt dans `Agentic-Financial-RAG-Analyst-G0` (nouveau dossier).
2. Refuse d'intervenir si la révision GitHub n'est plus celle auditée.
3. Crée `chore/g0-reproducible-env-20261117` depuis le `main` auditée.
4. Vérifie/applique le patch, crée `requirements.lock` via `uv` et lance le
   bootstrap Python 3.11 + tests.
5. Complète le journal, commite les modifications et pousse la branche.
6. Affiche le lien de création d'une pull request, sans fusionner `main`.

Préconditions : Git avec authentification GitHub en écriture, Python 3.11,
`uv` et accès Internet. Tesseract et Ollama sont diagnostiqués séparément.

Pour vérifier **uniquement le patch** sans installation, commit ou push :

```bash
bash APPLIQUER_ET_PUSH_G0.sh ./G0-check --dry-run
```

**Attention :** la suite de tests ne valide pas encore les calculs, les
citations ni la qualité des réponses financières. Il faut poursuivre G1-G4.

Le patch a été produit à partir des blobs GitHub identifiés par :
- `requirements.txt`: `54dcf7b18e19ce6b20771dc0ba9278aa9954feef`
- `.env.example`: `bf1d347f8c95e8d54ec55e35b194fc6416ad9af1`

Commandes et artefacts supplémentaires :
- `g0_changes.patch` : patch Git prêt à appliquer ;
- `files/` : les nouveaux fichiers proposés, prêts à être inspectés ;
- `logs/` : tests, diagnostics et rapport de blocage.
