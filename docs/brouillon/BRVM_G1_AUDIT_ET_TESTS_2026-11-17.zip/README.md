# Pack G1 — Audit, reproduction et préparation Copilot

**Projet :** `BeediGoua/Agentic-Financial-RAG-Analyst`.
**Base contrôlée :** branche `main` après fusion G0, commit `edaf61c81fcbeebfb6f452440ec05a712e1f6d5a`.
**But :** aider Copilot à implémenter G1 avec preuves, non se substituer aux tests du vrai dépôt.

## Contenu

- `docs/RAPPORT_G0_VALIDE_G1_AUDIT_2026-11-17.md` : rapport de contexte, capacités, bilan G0, risques G1, preuves et dialogue oral.
- `COPILOT_PROMPT_G1.md` : mission détaillée à copier dans Copilot Agent.
- `tests_g1/` : **34 tests d'acceptation** à copier dans `tests/` du dépôt.
- `candidate/G1_CANDIDATE_CORE.patch` : patch expérimental de cinq modules, testé sur un miroir partiel.
- `candidate/g1_secure_downloads_recipe.py` : propositions de sécurité TLS et de téléchargement atomique, garde SHA Git.
- `candidate/g1_controlflow_recipe.py` : propositions de codes de sortie, santé et parsing, garde SHA Git.
- `diagnostics/BASELINE_15_TESTS.txt` : première exécution sur le miroir partiel (4 passent, 11 échouent).
- `diagnostics/CANDIDATE_15_TESTS.txt` : exécution des mêmes 15 tests après les corrections candidates (15 passent).

## Utilisation dans GitHub Codespaces

1. Ouvre le dépôt à jour et crée `g1_preparation/` (dossier temporaire).
2. Dépose-y le ZIP puis utilise :

```bash
unzip g1_preparation/BRVM_G1_AUDIT_ET_TESTS_2026-11-17.zip -d /tmp/brvm_g1_audit
```

3. Ouvre Copilot Chat en mode Agent et colle `COPILOT_PROMPT_G1.md`.
4. Copilot effectue l'audit, applique ou adapte les correctifs, exécute les tests **sur le vrai clone**, puis pousse une branche G1/PR. Ne fusionne pas sans revue.

## Sécurité et limites

Ce ZIP ne contient aucun PDF privé, aucune clé API et aucun modèle. Les tests ne doivent pas accéder au réseau. Le terminal de préparation ne pouvait pas cloner `github.com`, d'où l'expression **« miroir partiel »** ; seuls les 15 tests du prototype corrigé sont prouvés localement. La CI GitHub doit confirmer le comportement final.

**Ne pas copier `candidate` tel quel à la place de `app/`.** Le patch et les recettes sont des propositions à vérifier, pas un dépôt complet à écraser.
