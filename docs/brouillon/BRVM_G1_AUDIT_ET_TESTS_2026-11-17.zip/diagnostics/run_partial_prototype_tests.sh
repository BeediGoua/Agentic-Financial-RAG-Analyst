#!/usr/bin/env bash
set -euo pipefail
# Only tests whose application modules were available in the earlier partial mirror.
# Do NOT present as a complete test run on the live GitHub repository.
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SUBSET=(
 test_g1_valid_pdf_is_accepted
 test_g1_reject_pdf_header_with_corrupt_body
 test_g1_reject_encrypted_unreadable_pdf
 test_g1_reject_zero_page_pdf
 test_g1_extraction_text_empty_is_not_healthy
 test_g1_extraction_cached_unknown_page_count_not_healthy
 test_g1_extraction_errors_cannot_be_healthy
 test_g1_extraction_table_empty_batch_is_not_healthy
 test_g1_extraction_tables_zero_count_is_legitimate
 test_g1_ingestion_failure_must_propagate_exit
 test_g1_sika_failure_must_propagate_exit
 test_g1_macro_failure_must_propagate_exit
 test_g1_corrupt_pdf_extraction_must_not_create_cache_file
 test_g1_zero_length_cached_pages_are_not_accepted
 test_g1_force_extraction_failure_preserves_existing_good_output
)
NODES=()
for name in "${SUBSET[@]}"; do NODES+=("$ROOT/tests_g1/test_g1_contracts.py::$name"); done
python -m pytest -q "${NODES[@]}" --tb=short
