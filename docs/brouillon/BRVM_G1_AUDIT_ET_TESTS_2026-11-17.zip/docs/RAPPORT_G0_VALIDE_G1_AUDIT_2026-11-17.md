# Financial RAG Analyst BRVM — Rapport vivant

**Version : 2026-11-17 / G0 clôturé, G1 préparé (non fusionné).**
**Référentiel GitHub :** `BeediGoua/Agentic-Financial-RAG-Analyst`.
**Main après fusion G0 :** `edaf61c81fcbeebfb6f452440ec05a712e1f6d5a`.
**Point de départ des correctifs G1 :** ce `main`, sans autres changements non audités.

## 1. Contexte et problématique

Un analyste financier doit exploiter plusieurs rapports BRVM, parfois en PDF texte, parfois scannés, avec des tableaux, des années et des périmètres comptables variables. Une réponse utile ne consiste pas seulement à générer du texte : elle doit retrouver le **bon document**, l'**exercice correct**, le **bon chiffre** et sa **page source**, et refuser de conclure sans preuve suffisante.

**Problématique :** construire un pipeline RAG d'analyse financière BRVM reproductible, traçable, résistant aux erreurs d'ingestion et d'extraction, évalué sur des questions financières, capable de produire une réponse sourcée et de distinguer information manquante et zéro réel.

## 2. Capacités cibles

1. Collecter et vérifier les sources (BRVM, cours, données macro selon disponibilité) ;
2. Détecter et extraire PDF texte, images et tableaux, en préservant provenance, société, année et page ;
3. Nettoyer, segmenter, indexer avec FAISS et métadonnées correctes ;
4. Effectuer BM25 + dense + hybride + reranking avec filtres rigoureux ;
5. Générer réponses et refus justifiés ; vérifier les nombres, unités, citations et incertitudes ;
6. Évaluer, observer et servir une API fiable, puis mesurer l'intérêt éventuel de l'agentique.

## 3. Réalisations actuelles (sans surdéclarer leur maturité)

Le dépôt possède déjà des modules d'ingestion, extraction texte/tables, nettoyage, chunking, embeddings, FAISS, retrieval, reranking et génération Ollama. Il existe des résultats historiques de retrieval/reranking, mais **pas encore d'évaluation financière de bout en bout démontrant la fidélité des réponses**. La présence de classes « agent » ne prouve pas que les étapes sont robustes.

## 4. G0 — État final vérifié

**Clôturé le 17/11/2026.** PR `#1` fusionnée : https://github.com/BeediGoua/Agentic-Financial-RAG-Analyst/pull/1

- Python 3.11 et `.venv` isolée ; scripts `make setup`, `make doctor`, `make test`.
- `requirements.lock` transitif hashé, installation dans un environnement propre ; `pip check` sans conflit sur la plateforme CI Ubuntu 24.04.
- Tesseract avec `fra`/`eng` ; diagnostic core séparé de doctor-full.
- Quatre révisions Hugging Face épinglées ; téléchargement volontaire et hors CI.
- CI GitHub Actions verte pour le dernier commit de branche `13730b0e48e1ebdd5bccf7a5c531a3c03e6b8bf4`, runs `44083242111` et `44083234758` ; 8 tests G0 réussis selon journal et exécutions précédentes.
- Ollama et poids HF absents de Codespaces : **acceptable pour G0**, non validé pour l'inférence complète.

**Réserve :** G0 ne prouve ni qualité financière ni fiabilité des sorties d'ingestion ; c'est précisément l'objet des prochaines étapes.

## 5. G1 — Risques identifiés par relecture du code `main`

### P0 : bloquants

| ID | Module | Observation prouvée par lecture | Impact | Action G1 |
| --- | --- | --- | --- | --- |
| G1-P0-01 | `app/ingest/run_all.py` | Exceptions journalisées mais non propagées | Exit 0 et faux succès du pipeline | Aggregate failures, code sortie non nul, tests CLI |
| G1-P0-02 | `app/extraction/extraction_quality_agent.py` + superviseur | Lot sans PDF/pages/tables peut être classé `HEALTHY` | Étape suivante exécutée sans données | `EMPTY` / `UNHEALTHY`, propagation robuste |
| G1-P0-03 | `app/ingest/quality.py` | Vérification `%PDF-` + taille/lecture de quelques octets | HTML/faux PDF accepté, corruption non détectée | Parser réellement avec PyMuPDF, contrôler pages et chiffrement |
| G1-P0-04 | `brvm_source.py`, `storage.py`, `sika_source.py` | Vérification TLS explicitement désactivée | Interception/corruption de données | Supprimer les `verify=False` et suppression d'avertissements |

### Défauts associés dans le périmètre G1

| ID | Module | Risque / recommandation |
| --- | --- | --- |
| G1-05 | `sika_source.py` | Échecs par ticker capturés puis oubliés : relever en fin d'ingestion avec détails |
| G1-06 | `macro_source.py` | Si les deux fichiers EDEN manquent, le programme peut terminer sans erreur : exiger les sources demandées |
| G1-07 | `run_reports.py`, `run_extraction.py`, `extraction_audit.py` | CLI signale un échec dans le texte mais retourne 0 : exit code fiable |
| G1-08 | `StorageAgent.download` | Écrit directement le PDF avant validation ; cache non vide réutilisé même corrompu : téléchargement temporaire + validation + remplacement atomique |
| G1-09 | `PDFTextExtractionAgent`, `TableExtractionAgent` | Une extraction forcée peut détruire l'ancien résultat avant un crash ; un cache incomplet peut passer pour `already_exists` : atomicité + vérification |
| G1-10 | `extraction_supervisor.py` | Statuts tables `UNHEALTHY` mal propagés : agrégation selon la gravité maximale |
| G1-11 | `ingestion_health.py` | `[]` peut devenir `HEALTHY` ; un PDF invalide parmi beaucoup de succès ne déclenche pas nécessairement l'alerte : fail-closed |
| G1-12 | `ingest/utils.py::parse_year_filter` | Type `list[str]` annoncé mais `.strip()` appelé sur la liste : gérer liste et CSV/range |
| G1-13 | Découverte BRVM | Nombreux WARN sans trace de couverture complète ; risque de collecte partielle silencieuse : distinguer « aucun rapport », « toutes requêtes ont échoué » et « filtre sans correspondance » |
| G1-14 | Manifests | Vérifier cohérence fichier-hash-manifest ; éviter manifest de succès sur fichier tronqué et ne pas inventer la provenance |

**Points à ne pas mélanger :** exactitude des filtres hybrides, collision des index FAISS = G2 ; benchmark Recall@K = G3 ; vérification des citations et des valeurs financières = G4.

## 6. Expériences réalisées pour préparer G1

### Ce qui a été réellement testé localement

Le réseau du terminal d'audit ne résout pas `github.com`. Nous avons donc utilisé une **reconstitution locale partielle** d'un audit antérieur. Ses modules ne forment pas un clone intégral. Les comportements testés doivent être revérifiés sur un clone propre dans Codespaces.

- 15 tests ciblés sur ingestion, qualité PDF, états d'extraction et atomicité texte.
- **Avant correctifs (miroir partiel) : 4 réussis, 11 échoués** ; les échecs reproduisent des défauts ou leurs symptômes.
- **Après correctifs candidats (même miroir partiel) : 15 réussis, 0 échoué**.
- Code candidat compilé avec Python, patch `G1_CANDIDATE_CORE.patch` vérifié applicable à la base locale de ce prototype.
- **34 tests d'acceptation complets** fournis pour être exécutés dans le vrai dépôt. Ils n'ont **pas** tous été exécutés localement faute de clone intégral ; ne pas annoncer 34 réussites avant la CI de Codespaces.
- Aucune collecte réelle des sites BRVM/Sika/BCEAO ni inférence Ollama/HF n'a été réalisée pendant ces tests.

### Artefacts G1 fournis

- `tests_g1/test_g1_contracts.py` et `tests_g1/test_g1_orchestration_and_storage.py` : 34 tests de non-régression hors réseau.
- `candidate/G1_CANDIDATE_CORE.patch` : correctifs expérimentaux de 5 modules (exceptions, PDF, macro, qualité d'extraction, écriture PDF texte atomique).
- `candidate/g1_secure_downloads_recipe.py` : propositions TLS + téléchargements PDF atomiques + propagation Sika, avec validation d'empreintes Git.
- `candidate/g1_controlflow_recipe.py` : autres corrections CLI, santé ingestion, filtre d'années, superviseur d'extraction, avec validation d'empreintes Git.
- `diagnostics/BASELINE_15_TESTS.txt` / `CANDIDATE_15_TESTS.txt` : sorties réelles des tests locaux comparatifs.
- `COPILOT_PROMPT_G1.md` : mission et conditions de livraison.

**Important :** les patchs/recettes sont des **points de départ revus localement**, pas une preuve que les corrections sont intégrées au dépôt. Copilot doit inspecter, adapter, exécuter les 34 tests dans le vrai code et traiter notamment l'atomicité de l'extraction des tableaux qui reste à implémenter.

## 7. Conditions de clôture G1

- Les 4 P0 supprimés, plus les défauts G1 adjacents documentés ou corrigés.
- Les commandes CLI ont des codes d'erreur fiables, y compris pour aucun PDF et pour une source indisponible, sans transformer un cas « aucun document correspondant au filtre » en succès implicite.
- PDF non parsable / chiffré inaccessible / HTML déguisé rejetés et pas de manifest `success`.
- TLS vérifié par défaut ; pas de `verify=False` ni de suppression globale d'alertes.
- Téléchargements et extractions atomiques, cache validé avant réutilisation, anciens fichiers préservés si retry échoue.
- Tests G0 conservés + 34 tests G1 validés dans une installation propre (`make setup`, `make test`, `pip check`).
- CI GitHub Actions verte **sur le dernier commit G1**, journal `docs/JOURNAL_G1.md` avec causes, correctifs, commandes et risques résiduels.
- Pull request G1 ouverte, revue, puis fusion seulement après vérification.

## 8. Présentation orale (réutilisable)

**Projet, version courte :** « Je construis un assistant d'analyse financière pour la BRVM. Il collecte les rapports, extrait les textes et les tableaux, retrouve les passages pertinents avec une recherche hybride et produit des réponses sourcées. La difficulté principale n'est pas de brancher un LLM aux PDF, mais de garantir la qualité de la chaîne documentaire, la validité des chiffres et la traçabilité. »

**G0 :** « J'ai commencé par rendre l'environnement reproductible : Python 3.11, verrouillage des versions, tests et CI dans un environnement indépendant. C'est indispensable pour comparer sérieusement les méthodes de retrieval par la suite. »

**G1, une fois validé :** « Ensuite, j'ai sécurisé l'ingestion et l'extraction. Nous avions identifié des erreurs qui pouvaient passer silencieusement, des PDF invalides acceptés et des caches incomplets. J'ai ajouté des validations réelles des fichiers, des écritures atomiques et des tests qui obligent les commandes à signaler correctement une erreur. »

**Question de relance : pourquoi les écritures atomiques ?** « Si un téléchargement s'interrompt au milieu, le fichier final ne doit jamais être remplacé par des octets partiels. J'écris dans un fichier temporaire, je valide le contenu, puis je remplace l'ancien fichier seulement si toutes les vérifications passent. »

**Question de relance : pourquoi les tests G1 ne nécessitent-ils pas les données BRVM ?** « Nous injectons des PDF synthétiques et des réponses HTTP simulées pour reproduire systématiquement les cas d'erreur. Les tests fonctionnent même lorsque les serveurs externes sont indisponibles. Les véritables tests d'intégration réseau seront séparés et explicites. »

## 9. Suite logique

G0 **clos** → G1 **préparé, à intégrer et valider dans Codespaces** → G2 **cohérence des métadonnées et de l'indexation** → G3 **évaluation retrieval** → G4 **fiabilité des réponses et des citations** → G5 **API/observabilité** → G6 **agentique mesurée**.

Le prochain rapport ne devra pas annoncer « G1 validé » sur la seule base des prototypes locaux. Il faudra une PR et les résultats CI du vrai dépôt.
