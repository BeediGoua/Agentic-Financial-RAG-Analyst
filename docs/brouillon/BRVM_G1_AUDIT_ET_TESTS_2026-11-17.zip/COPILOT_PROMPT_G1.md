# Mission Copilot : finaliser G1 — intégrité ingestion et extraction BRVM

Tu travailles **dans le vrai clone GitHub Codespaces** du dépôt
`BeediGoua/Agentic-Financial-RAG-Analyst`. L'étape **G0 est fusionnée** dans
`main` et ses tests doivent rester verts. Ta mission est de finaliser **G1**, puis
**pousser une branche et créer une pull request**. Ne travaille ni dans un autre
repo ni sur `main` directement.

## 0. Documents et précautions

L'archive `BRVM_G1_AUDIT_ET_TESTS_2026-11-17.zip` est placée dans le dossier
temporaire `g1_preparation/` à la racine du dépôt.

1. `unzip g1_preparation/BRVM_G1_AUDIT_ET_TESTS_2026-11-17.zip -d /tmp/brvm_g1_audit`
2. Lis complètement `/tmp/brvm_g1_audit/README.md`,
   `/tmp/brvm_g1_audit/docs/RAPPORT_G0_VALIDE_G1_AUDIT_2026-11-17.md`, les deux suites
   de tests, les trois artefacts candidats et les logs de diagnostic.
3. `git status`, `git rev-parse HEAD`, `git log -5 --oneline` ; assure-toi que
   les changements G0 sont bien présents sur `main`.
4. Crée une branche `fix/g1-ingestion-extraction-integrity-20261117` depuis le
   dernier `main` à jour. Si quelqu'un a modifié le dépôt, adapte-toi sans écraser
   son travail.
5. N'ajoute au commit ni le ZIP temporaire, ni `g1_preparation/`, ni secrets,
   ni `.venv`, ni modèles HF, ni données financières non publiables.

## 1. Établir un état initial documenté

Copie les deux fichiers de `/tmp/brvm_g1_audit/tests_g1/` dans le répertoire
`tests/` du vrai dépôt, en conservant leurs noms. Ils contiennent **34 tests
hors ligne** d'intégrité / non-régression, sans dépendance aux serveurs BRVM,
Sika, Ollama ou Hugging Face.

Exécute d'abord `make doctor`, puis :

```bash
.venv/bin/python -m pytest -q tests/test_g1_contracts.py tests/test_g1_orchestration_and_storage.py
```

Plusieurs échecs sont attendus dans l'état initial. Enregistre précisément les
cas échoués dans `docs/JOURNAL_G1.md`. **Ne marque pas artificiellement ces tests
comme `xfail` pour obtenir une CI verte.** Ne retire pas les tests difficiles :
si l'un est mal spécifié, explique pourquoi et remplace-le par un test valide.

## 2. Corriger les 4 anomalies P0

### P0-01 : aucune erreur silencieuse d'ingestion

- `app/ingest/run_all.py` : si macro, Sika ou BRVM échoue, transmettre un code
de sortie non nul ; collecter les échecs de chacune des sources en conservant
un rapport compréhensible.
- `app/ingest/sika_source.py` : les erreurs par ticker ne doivent pas être
supprimées en silence. Échec partiel à tracer et propager en fin d'exécution.
- `app/ingest/macro_source.py` : si des données EDEN requises manquent, échec
explicite ; ne jamais fabriquer des valeurs par défaut ni déclarer un succès
sur zéro donnée.
- `app/ingest/run_reports.py` : si aucun rapport n'a été découvert, ou si des
rapports ont échoué, le statut doit être clair et le CLI doit échouer par défaut.
Si une recherche vide est autorisée, documente un mode explicite `--allow-empty`
et ne l'active jamais silencieusement.
- `app/ingest/ingestion_health.py` : zéro document ou des erreurs de traitement
ne peuvent jamais produire `HEALTHY`. Traite séparément les doublons déjà
validés et les nouveaux rapports effectivement ingérés.

### P0-02 : échec d'extraction réellement propagé

- `app/extraction/extraction_quality_agent.py` : zéro fichier ou zéro page n'est
pas un succès. Une extraction sans tableaux est acceptable **si le PDF a été
réellement traité**, contrairement à zéro PDF traité.
- `app/extraction/extraction_supervisor.py` : agréger les gravités texte et
tables sans qu'un composant sain masque un autre en échec.
- `app/extraction/run_extraction.py` et
  `app/extraction/extraction_audit.py` : code de sortie non nul en cas d'échec.
- `app/pipeline/run_data_pipeline.py` : confirmer par test que le pipeline
s'arrête lorsque l'ingestion ou l'extraction retourne un échec.

### P0-03 : vraie validation des PDF

- `app/ingest/quality.py` : vérifier `fitz.open`, `is_pdf`, au moins une page,
lecture possible et absence de protection nécessitant un mot de passe ; gérer
les faux PDF avec en-tête `%PDF-`, les HTML déguisés, les fichiers tronqués et
les fichiers trop gros.
- `app/ingest/storage.py` : ne laisser entrer dans le RAW que des PDF validés ;
nom `.part` temporaire, lecture HTTP en streaming bornée, validation, puis
`os.replace` atomique ; ne pas détruire un PDF valide lors d'une relance ratée.
- Une erreur d'extraction ne doit jamais créer un cache vide ou partiel marqué
`already_exists`. Réparer `PDFTextExtractionAgent` et `TableExtractionAgent` :
écriture atomique, vérification du cache, métadonnées conservées.
- Les manifests `success` doivent pointer sur un PDF réellement validé avec
hash correct. Si la source est corrompue ou l'enregistrement échoue, journaliser
le problème et conserver le dernier état cohérent.

### P0-04 : sécurité TLS obligatoire

- Retirer `session.verify = False`, `verify=False` et la suppression globale des
alertes `InsecureRequestWarning` dans : `brvm_source.py`, `storage.py`,
`sika_source.py` ; contrôler également les autres téléchargeurs.
- En cas d'erreur de certificat, laisser échouer explicitement et documenter
comment configurer un CA de confiance. **Ne jamais contourner TLS pour faire
passer un test.**

## 3. Propositions de correctifs fournies (à relire, pas à appliquer aveuglément)

- `candidate/G1_CANDIDATE_CORE.patch` : cinq modules corrigés dans une
  reconstitution locale partielle. Les **15 tests ciblés de ce prototype passent**
  après application. **Sa correspondance exacte avec le dernier `main` n'a PAS
  été certifiée par une application sur le vrai clone** : utilise
  `git apply --check`, vérifie le diff, adapte si nécessaire.
- `candidate/g1_secure_downloads_recipe.py` : script `--check` / `--apply` pour
  TLS, Sika et téléchargement PDF atomique. Il compare les SHA Git des fichiers
  d'origine avant toute écriture. Un échec d'empreinte signifie « arrêter et
  réexaminer », jamais contourner la garde.
- `candidate/g1_controlflow_recipe.py` : même principe pour les CLI, la
  santé ingestion, le parsing des années et le superviseur d'extraction.
- Les recettes peuvent être utilisées **indépendamment**. Vérifie leur
  cohérence mutuelle et n'exécute que les transformations nécessaires.

**N'applique jamais des changements sans avoir d'abord créé la branche G1 et
inspecté leur effet.** Le codemod est une aide, pas une autorité.

## 4. Cas de test à respecter

Les **34 tests** visent notamment :

- PDF valide, faux en-tête PDF, PDF chiffré, fichier sans pages ;
- téléchargement HTML déguisé en PDF, interruption HTTP, mauvais cache, TLS ;
- exceptions Sika, macro et BRVM ;
- rapport vide, partiellement invalide, traitement uniquement en doublons ;
- extraction texte sans fichiers ou avec cache incomplet ;
- extraction des tableaux sans PDFs ou sans tableaux ;
- échec au milieu d'une extraction forcée : préserver les anciennes sorties ;
- résultats PDF/métadonnées conservés ;
- codes de sortie CLI `run_reports`, `run_extraction`, `extraction_audit`,
  et pipeline global ;
- parsing des années listes et intervalles.

**Complète ces tests si un défaut important du code réel reste non couvert.**
Les simulations ne doivent pas appeler de sites réels. Les véritables tests
réseau, si tu les réalises, restent une étape optionnelle contrôlée et distincte.

## 5. Qualité du correctif et compatibilité

Ne casse pas les schémas Pydantic, les noms de fichiers, les chemins JSONL ni
les métadonnées utilisées plus tard par G2/G3. Préserve les anciens fichiers
valides si un retry échoue. Ne mélange pas G1 avec les corrections des filtres
hybrides FAISS (G2) ou les métriques de génération (G4).

Si les 34 tests semblent insuffisants, analyse les fichiers complets des deux
phases (ingestion et extraction), y compris fichiers utilitaires, superviseurs,
source BRVM, stockage, santé, audit et transitions pipeline, puis écris des
nouveaux tests pour chaque problème supplémentaire réellement détecté.

Respecte l'état du dépôt : G0 est déjà fusionné, ne le reconstruis pas.
L'absence d'Ollama et des poids HF ne bloque pas G1.

## 6. Validation dans une nouvelle installation

Une fois les corrections terminées, exécute :

```bash
make doctor
make test
.venv/bin/python -m pip check
.venv/bin/python -m pytest -q tests/test_g1_contracts.py tests/test_g1_orchestration_and_storage.py
.venv/bin/python -m compileall -q app tests
```

Vérifie la CLI en sous-processus pour les sorties d'échec, notamment le code de
retour de `python -m app.ingest.run_all --only-macro` avec les fichiers macro
absents. Cette vérification doit se faire dans un environnement isolé pour ne
pas modifier de vraies données. Ajoute un test de bout en bout synthétique sur
un PDF normal et une interruption simulée.

Ajoute si nécessaire un workflow `.github/workflows/g1-ci.yml` ou étends G0 CI
pour inclure G1. La CI obligatoire ne doit jamais télécharger des modèles
volumineux, démarrer Ollama ou appeler des sites externes.

Fais aussi l'essai sur une nouvelle `.venv` : **les tests doivent passer à
partir du lockfile versionné**, sans dépendance installée manuellement.

## 7. Journal, push et PR

Crée `docs/JOURNAL_G1.md` (une ligne ou section par défaut) indiquant :

- problème, impact sur les sorties financières et cause racine ;
- fichier/ligne concernés, correction choisie et alternatives écartées ;
- tests rouges avant, verts après et preuve par commande ;
- statut final des 4 P0 et des anomalies associées ;
- exceptions/réserves restantes, si elles existent.

Exclus `g1_preparation/` du commit et contrôle `git diff --check`, `git status`,
le contenu de l'index et les permissions des scripts. Pousse ta branche et
ouvre une PR vers `main`. Vérifie **la CI sur le dernier commit**. En cas d'échec,
corrige et pousse de nouveau. **Ne fusionne pas automatiquement.**

## 8. Rapport final demandé

Fournis les liens PR et runs CI, les commits, le diff des modules changés, le
nombre exact de tests passés/échoués/ignorés, le tableau des P0 corrigés, les
limites et un verdict clair : `G1 CANDIDAT VALIDÉ POUR REVUE` ou
`G1 NON VALIDÉ`. Pas de succès proclamé sans preuves.
