"""G1 control-flow changes for a CLEAN checkout at the pinned pre-G1 SHA.

Optional implementation STARTER, not a fully audited replacement for review.
Run --check, inspect diffs, then --apply on a dedicated branch. The repository
must match GitHub main after G0 merge; aborts on changed files.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import subprocess

EXPECTED={
 'app/ingest/run_reports.py':'2c9caa2478c6366602c59a9946bf322775b68e96',
 'app/ingest/ingestion_health.py':'bd68654184b494775683080acab6e25b0dcc0206',
 'app/ingest/utils.py':'ac0c35a8d1bb69468f7ea1c69617232d60c4f78a',
 'app/extraction/extraction_supervisor.py':'251572ba422de481b313cbbe453768a08eb454f5',
 'app/extraction/run_extraction.py':'2f3a8d6b5b5fbfa4b8ace5ed6dbc8a9fc86605d1',
 'app/extraction/extraction_audit.py':'b86263be72ff133acd8e69f4b570784ecaae4fed',
}

def replace_once(s,old,new,path):
  n=s.count(old)
  if n!=1:raise RuntimeError(f'{path}: replacement anchor occurs {n} times: {old[:80]!r}')
  return s.replace(old,new)

def propose(root):
  result={}
  for rel,expect in EXPECTED.items():
    path=root/rel
    if not path.is_file():raise RuntimeError(f'missing {rel}')
    sha=subprocess.check_output(['git','hash-object',str(path)],text=True,cwd=root).strip()
    if sha!=expect:raise RuntimeError(f'{rel} changed (expected {expect}, found {sha}); review manually')
    s=path.read_text(encoding='utf-8')
    if rel.endswith('run_reports.py'):
      s=replace_once(s,'    print(json.dumps({k: v for k, v in summary.items() if k != "results"}, indent=2, ensure_ascii=False))',
        '''    print(json.dumps({k: v for k, v in summary.items() if k != "results"}, indent=2, ensure_ascii=False))
    if summary["discovered_reports"] == 0 or summary["errors"] > 0 or summary["invalid_pdfs"] > 0 or summary["overall_status"] in {"EMPTY", "CRITICAL", "UNHEALTHY"}:
        raise SystemExit(1)''',rel)
    elif rel.endswith('ingestion_health.py'):
      start=s.index('        # Success rate\n')
      end=s.index('        # Validation checks analysis\n',start)
      block='''        # Count duplicates as available validated data, not new ingestion.
        total = health_report["metrics"]["total_processed"]
        succeeded = health_report["metrics"]["successful"]
        duplicates = health_report["metrics"]["duplicates_detected"]
        errors = health_report["metrics"]["errors"]
        invalid = health_report["metrics"]["invalid_pdfs"]
        health_report["metrics"]["success_rate"] = round(succeeded / total, 4) if total else 0.0
        health_report["metrics"]["available_rate"] = round((succeeded + duplicates) / total, 4) if total else 0.0
        if total == 0:
            health_report["alerts"].append("CRITICAL: No reports processed")
        if errors > 0 or invalid > 0:
            health_report["alerts"].append(f"CRITICAL: {errors} ingestion errors and {invalid} invalid PDFs")
        elif total and succeeded + duplicates == 0:
            health_report["alerts"].append("CRITICAL: No usable documents")

'''
      s=s[:start]+block+s[end:]
      # Current status decision remains ALERT based: CRITICAL if one of above.
    elif rel.endswith('utils.py'):
      start=s.index('def parse_year_filter(')
      end=s.index('def load_yaml(',start)
      block='''def parse_year_filter(value: str | list[str] | None) -> list[str] | None:
    """Accept CSV years, an inclusive range or a list of years."""
    if value is None:
        return None
    if isinstance(value, list):
        result = [str(y).strip() for y in value if str(y).strip()]
        return result or None
    value = str(value).strip()
    if not value:
        return None
    if "-" in value and "," not in value:
        parts = value.split("-", 1)
        if len(parts) != 2 or not all(x.strip().isdigit() and len(x.strip()) == 4 for x in parts):
            raise ValueError(f"Invalid year range: {value}")
        start_year, end_year = map(int, parts)
        if start_year > end_year:
            start_year, end_year = end_year, start_year
        if end_year - start_year > 100:
            raise ValueError("Year range is unexpectedly large")
        return [str(y) for y in range(start_year, end_year + 1)]
    return [x.strip() for x in value.split(",") if x.strip()]


'''
      s=s[:start]+block+s[end:]
    elif rel.endswith('extraction_supervisor.py'):
      start=s.index('        overall_status = "HEALTHY"\n')
      end=s.index('        report = {\n',start)
      block='''        # Fail closed: even the table phase can invalidate an extraction run.
        severity = {"HEALTHY": 0, "DEGRADED": 1, "UNHEALTHY": 2}
        statuses = (text_quality["status"], table_quality["status"])
        overall_status = max(statuses, key=lambda value: severity.get(value, 2))

'''
      s=s[:start]+block+s[end:]
    elif rel.endswith('run_extraction.py'):
      s=replace_once(s,'    print("=" * 60)\n\n\nif __name__ == "__main__":',
        '    print("=" * 60)\n    if report["overall_status"] != "HEALTHY":\n        raise SystemExit(1)\n\n\nif __name__ == "__main__":',rel)
    elif rel.endswith('extraction_audit.py'):
      s=replace_once(s,'''        print("\\nDécision : extraction suffisante pour passer à l'étape suivante.")''',
        '''        print("\\nDécision : extraction suffisante pour passer à l'étape suivante.")

    if report["overall_status"] == "FAIL":
        raise SystemExit(1)''',rel)
    result[rel]=s
  return result

if __name__=='__main__':
  p=argparse.ArgumentParser()
  action=p.add_mutually_exclusive_group(required=True)
  action.add_argument('--check',action='store_true')
  action.add_argument('--apply',action='store_true')
  opts=p.parse_args()
  root=Path.cwd()
  if not (root/'.git').exists():raise SystemExit('Run from Git repository root')
  changes=propose(root)
  if opts.check:
    for rel in changes:print(f'OK exact upstream blob: {rel}')
  else:
    for rel,s in changes.items():(root/rel).write_text(s,encoding='utf-8')
    print('Applied control-flow starter; review and run G1 tests.')
