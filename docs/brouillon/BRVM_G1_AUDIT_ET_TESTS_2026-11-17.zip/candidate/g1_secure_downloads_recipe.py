"""Reviewable G1 implementation recipe for the live GitHub checkout.

Usage: python candidate/g1_secure_downloads_recipe.py --check
       python candidate/g1_secure_downloads_recipe.py --apply

BEFORE apply, inspect every proposed change and create a feature branch.
The script checks original Git blob SHAs and aborts on unexpected sources.
It covers TLS and atomic PDF downloads. Other G1 work is in the test suite.
"""
from __future__ import annotations

import argparse
import subprocess
from pathlib import Path

EXPECTED = {
    'app/ingest/brvm_source.py': '9082432d2bec2baa0db71188b6cfe4ecaebcfb53',
    'app/ingest/sika_source.py': '556ecf6762841cb2280701eb0cb3f1bba32a2548',
    'app/ingest/storage.py': '2fd801819e7ac7119e74b27efc1003272698be24',
}


def exact(source: str, original: str, replacement: str, path: str) -> str:
    if source.count(original) != 1:
        raise RuntimeError(f'{path}: expected exactly one occurrence of {original!r}, got {source.count(original)}')
    return source.replace(original, replacement)


def proposed_changes(root: Path) -> dict[str, str]:
    changed = {}
    for rel, sha in EXPECTED.items():
        path=root/rel
        if not path.is_file():
            raise RuntimeError(f'Missing file: {path}')
        actual=subprocess.check_output(['git','hash-object',str(path)],text=True,cwd=root).strip()
        if actual != sha:
            raise RuntimeError(f'{rel}: base SHA changed ({actual}); expected {sha}. Review manually, DO NOT force.')
        s=path.read_text(encoding='utf-8')
        if rel.endswith('brvm_source.py'):
            s=exact(s,'import urllib3\n','',rel)
            s=exact(s,'urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)\n','',rel)
            s=exact(s,'        self.session.verify = False\n','',rel)
        elif rel.endswith('sika_source.py'):
            s=exact(s,'import urllib3\n','',rel)
            s=exact(s,'urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)\n','',rel)
            s=exact(s,'requests.get(url, headers=headers, timeout=timeout_s, verify=False)',
                      'requests.get(url, headers=headers, timeout=timeout_s)',rel)
            s=exact(s,'    from tqdm import tqdm\n    \n    for ticker in tqdm(tickers, desc="Fetching Sika Prices", unit="ticker"):',
                      '    from tqdm import tqdm\n    if not tickers:\n        raise RuntimeError("No tickers configured for Sika ingestion")\n    failures = []\n    \n    for ticker in tqdm(tickers, desc="Fetching Sika Prices", unit="ticker"):',rel)
            s=exact(s,'            logging.error(f" Failed fetching {ticker}: {e}")',
                      '            logging.error(f" Failed fetching {ticker}: {e}")\n            failures.append((ticker, str(e)))',rel)
            s=exact(s,'\nif __name__ == "__main__":',
                      '\n    if failures:\n        raise RuntimeError(f"Sika ingestion failed for {len(failures)} tickers: {failures}")\n\nif __name__ == "__main__":',rel)
        elif rel.endswith('storage.py'):
            s=exact(s,'import hashlib\n','import hashlib\nimport os\nimport tempfile\n',rel)
            s=exact(s,'import urllib3\n','',rel)
            s=exact(s,'urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)\n','',rel)
            s=exact(s,'        self.session.verify = False\n','',rel)
            start=s.index('    def download(self, report: ReportDocument) -> Path:')
            end=s.index('    def save_metadata(', start)
            replacement='''    def download(self, report: ReportDocument) -> Path:
        """Atomic validated PDF download, never reuse invalid cached bytes.

        Safe against partial HTTP transfers, HTML login pages and corrupted
        documents with PDF magic bytes. Network calls retain TLS verification.
        """
        from app.ingest.quality import QualityAgent

        validator = QualityAgent()
        output_path = self.build_path(report)
        if output_path.exists():
            valid, _, _ = validator.validate_pdf(output_path)
            if valid:
                return output_path

        temp_path = None
        try:
            # Connection/read timeouts and bounded disk usage.
            with self.session.get(report.pdf_url, timeout=(10, 60), stream=True) as response:
                response.raise_for_status()
                with tempfile.NamedTemporaryFile(
                    mode="wb", dir=output_path.parent,
                    prefix=f".{output_path.name}.", suffix=".part", delete=False,
                ) as tmp:
                    temp_path = Path(tmp.name)
                    total = 0
                    for block in response.iter_content(chunk_size=65536):
                        if not block:
                            continue
                        total += len(block)
                        if total > validator.max_pdf_size:
                            raise ValueError("PDF exceeds configured maximum size")
                        tmp.write(block)

            valid, reason, _ = validator.validate_pdf(temp_path)
            if not valid:
                raise ValueError(f"Downloaded file is not a valid PDF: {reason}")
            os.replace(temp_path, output_path)
            temp_path = None
            return output_path
        finally:
            if temp_path is not None:
                temp_path.unlink(missing_ok=True)

'''
            s=s[:start]+replacement+s[end:]
        changed[rel]=s
    return changed


def main():
    p=argparse.ArgumentParser()
    mode=p.add_mutually_exclusive_group(required=True)
    mode.add_argument('--check',action='store_true')
    mode.add_argument('--apply',action='store_true')
    args=p.parse_args()
    root=Path.cwd()
    if not (root/'.git').exists():
        raise SystemExit('Run from the root of a local Git checkout')
    changes=proposed_changes(root)
    if args.check:
        print('All Git source hashes verified. Candidate edits:')
        for x,s in changes.items():print(f'  {x} -> {len(s)} UTF-8 chars')
    else:
        for rel,text in changes.items():
            (root/rel).write_text(text,encoding='utf-8')
        print('Applied TLS and atomic download candidate. Review the diff and run tests.')

if __name__=='__main__':main()
